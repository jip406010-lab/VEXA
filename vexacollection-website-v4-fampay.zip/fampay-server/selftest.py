# Offline test: fake Firestore + fake Gmail. Run:  python server.py --selftest
import os, tempfile, time
from datetime import datetime, timezone
from fampay_core import Config
import server as S


class FakeFS:
    def __init__(self): self.docs, self.paid = {}, []
    def get(self, path):
        d = self.docs.get(path.split("/", 1)[1])
        return (dict(d), "2026-01-01T00:00:00Z") if d else (None, None)
    def mark_paid(self, oid, order, ut, utr):
        self.paid.append(oid); self.docs[oid]["paymentStatus"] = "PAID"


def order(total, utr):
    return {"paymentMethod": "UPI", "paymentStatus": "PENDING", "total": total, "upiTransactionRef": utr,
            "phone": "9876543210", "createdAt": datetime.now(timezone.utc), "paymentHistory": []}


def run():
    cfg = Config(gmail_address="x@gmail.com", gmail_app_password="x", upi_id="shop@fam", min_amount=1, max_amount=100000)
    fs = FakeFS()
    app = S.App(cfg, fs, os.path.join(tempfile.mkdtemp(), "t.db"))
    now = int(time.time())
    mail = {"amt": 49900}
    def fake_search(utr):
        em = {"sender_ok": True, "utr_match": True, "amount_paise": mail["amt"], "paid_at": now - 90,
              "paid_src": "body", "arrival_at": now - 80}
        return "ok", [em], ""
    app.gw.mail.search_utr = fake_search
    fails = []
    def ok(name, cond):
        print(("PASS " if cond else "FAIL ") + name)
        if not cond: fails.append(name)

    def wait(oid, want, t=6):
        end = time.time() + t
        while time.time() < end:
            if app.status(oid)["state"] == want: return True
            time.sleep(0.1)
        return False

    fs.docs["VX-20260101-AAAA"] = order(499, "123456789012")
    out, code = app.verify("VX-20260101-AAAA")
    ok("verify starts checking", out["state"] in ("checking", "paid") and code == 200)
    ok("becomes paid", wait("VX-20260101-AAAA", "paid"))
    app.sync_paid()
    ok("firestore marked PAID once", fs.paid == ["VX-20260101-AAAA"])

    fs.docs["VX-20260101-BBBB"] = order(499, "123456789012")          # same UTR again
    app.verify("VX-20260101-BBBB")
    ok("duplicate UTR rejected", wait("VX-20260101-BBBB", "review"))
    app.sync_paid()
    ok("duplicate not marked PAID", "VX-20260101-BBBB" not in fs.paid)

    fs.docs["VX-20260101-CCCC"] = order(999, "555566667777")          # mail says 499, order says 999
    app.verify("VX-20260101-CCCC")
    ok("amount mismatch -> review", wait("VX-20260101-CCCC", "review"))
    ok("mismatch message", "amount" in app.status("VX-20260101-CCCC")["message"].lower())

    ok("bad order id rejected", app.verify("hacker")[1] == 400)
    ok("unknown order 404", app.verify("VX-20260101-ZZZZ")[1] == 404)
    web = S.create_web(app, {"https://shop.example"})
    c = web.test_client()
    r = c.post("/api/fampay/verify", json={"orderId": "VX-20260101-AAAA"}, headers={"Origin": "https://shop.example"})
    ok("http verify + CORS", r.get_json()["state"] == "paid" and r.headers.get("Access-Control-Allow-Origin") == "https://shop.example")
    r = c.get("/api/fampay/status/VX-20260101-AAAA", headers={"Origin": "https://evil.example"})
    ok("no CORS for other origins", "Access-Control-Allow-Origin" not in r.headers)
    print("ALL OK" if not fails else f"{len(fails)} FAILED")
    return 1 if fails else 0
