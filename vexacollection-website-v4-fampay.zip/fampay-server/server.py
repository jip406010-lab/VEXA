#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VEXACOLLECTION - FamPay auto-verify server (runs in Termux / any Python host).

Flow:
  1. Customer pays to the FamPay UPI ID and types the UTR on checkout; the website saves the
     order in Firestore (paymentStatus PENDING) and calls  POST /api/fampay/verify {orderId}.
  2. This server reads the order from Firestore (amount + UTR come from the ORDER, never from
     the browser), then looks for the matching FamPay payment e-mail in your Gmail (IMAP).
  3. Amount + time + UTR all match and the UTR was never used before  ->  the server sets the
     order to PAID in Firestore (orders, payments, orderTracking).  The checkout page updates live.

Run:   python server.py            (reads .env in this folder)
Test:  python server.py --selftest
"""
import json
import logging
import os
import re
import sqlite3
import sys
import threading
import time
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

from fampay_core import (Config, FamPayGateway, Hooks, OPEN_STATUSES, ensure_schema, epoch_now,
                         normalize_utr, utr_aliases, REVIEW_MSG)

log = logging.getLogger("vx_server")
ORDER_RX = re.compile(r"^VX-[0-9]{8}-[A-Z0-9]{4}$")


# ----------------------------------------------------------------------------- env
def load_dotenv(path=None):
    path = path or os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    except FileNotFoundError:
        pass


def env(name, default=""):
    return os.getenv(name, default).strip()


# ----------------------------------------------------------------------------- Firestore (REST, service account)
def _enc(v):
    if isinstance(v, bool):
        return {"booleanValue": v}
    if isinstance(v, int):
        return {"integerValue": str(v)}
    if isinstance(v, float):
        return {"doubleValue": v}
    if isinstance(v, datetime):
        return {"timestampValue": v.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")}
    if isinstance(v, str):
        return {"stringValue": v}
    if isinstance(v, list):
        return {"arrayValue": {"values": [_enc(x) for x in v]}}
    if isinstance(v, dict):
        return {"mapValue": {"fields": {k: _enc(x) for k, x in v.items()}}}
    if v is None:
        return {"nullValue": None}
    raise TypeError(type(v))


def _parse_ts(t):
    """Firestore timestamps can carry nanoseconds; keep 6 digits and force UTC."""
    m = re.match(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d+))?", t)
    dt = datetime.strptime(m.group(1), "%Y-%m-%dT%H:%M:%S")
    return dt.replace(microsecond=int((m.group(2) or "0")[:6].ljust(6, "0")), tzinfo=timezone.utc)


def _dec(v):
    if "stringValue" in v:
        return v["stringValue"]
    if "integerValue" in v:
        return int(v["integerValue"])
    if "doubleValue" in v:
        return float(v["doubleValue"])
    if "booleanValue" in v:
        return v["booleanValue"]
    if "timestampValue" in v:
        return _parse_ts(v["timestampValue"])
    if "arrayValue" in v:
        return [_dec(x) for x in v["arrayValue"].get("values", [])]
    if "mapValue" in v:
        return {k: _dec(x) for k, x in v["mapValue"].get("fields", {}).items()}
    return None


class Firestore:
    def __init__(self, project, database, keyfile):
        from google.oauth2 import service_account
        from google.auth.transport.requests import AuthorizedSession
        creds = service_account.Credentials.from_service_account_file(
            keyfile, scopes=["https://www.googleapis.com/auth/datastore"])
        self.s = AuthorizedSession(creds)
        self.root = f"projects/{project}/databases/{database}/documents"
        self.base = f"https://firestore.googleapis.com/v1/{self.root}"

    def get(self, path):
        """-> (dict, updateTime) or (None, None)"""
        r = self.s.get(f"{self.base}/{path}", timeout=20)
        if r.status_code == 404:
            return None, None
        r.raise_for_status()
        j = r.json()
        return {k: _dec(v) for k, v in j.get("fields", {}).items()}, j.get("updateTime")

    def mark_paid(self, order_id, order, update_time, utr):
        """One atomic commit: orders + payments + orderTracking. Precondition = order unchanged since read."""
        now = datetime.now(timezone.utc)
        hist = list(order.get("paymentHistory") or []) + [{"status": "PAID", "at": now, "by": "FamPay auto-verify"}]
        writes = [
            {"update": {"name": f"{self.root}/orders/{order_id}",
                        "fields": {k: _enc(v) for k, v in {
                            "paymentStatus": "PAID", "paymentHistory": hist, "paidAt": now,
                            "paymentVerifiedBy": "FamPay auto (Gmail UTR match)", "updatedAt": now}.items()}},
             "updateMask": {"fieldPaths": ["paymentStatus", "paymentHistory", "paidAt", "paymentVerifiedBy", "updatedAt"]},
             "currentDocument": {"updateTime": update_time}},
            {"update": {"name": f"{self.root}/payments/{order_id}",
                        "fields": {"status": _enc("PAID"), "updatedAt": _enc(now)}},
             "updateMask": {"fieldPaths": ["status", "updatedAt"]}},
            {"update": {"name": f"{self.root}/orderTracking/{order_id}",
                        "fields": {"paymentStatus": _enc("PAID"), "updatedAt": _enc(now)}},
             "updateMask": {"fieldPaths": ["paymentStatus", "updatedAt"]}},
        ]
        r = self.s.post(f"{self.base}:commit", json={"writes": writes}, timeout=20)
        if r.status_code >= 400:
            raise RuntimeError(f"firestore commit {r.status_code}: {r.text[:300]}")


# ----------------------------------------------------------------------------- gateway for website orders
class SiteGateway(FamPayGateway):
    """Same verification as the Telegram bot, but a success does NOT touch a wallet balance."""

    def credit(self, order_id, utr, received_paise, paid_at):
        conn = self.h.get_db()
        cur = conn.cursor()
        try:
            cur.execute("BEGIN IMMEDIATE")
            cur.execute("SELECT * FROM pending_payments WHERE order_id=?", (order_id,))
            row = cur.fetchone()
            if not row or row["status"] not in OPEN_STATUSES:
                conn.rollback()
                return "not_open", None
            if received_paise != int(row["amount"]) * 100:
                conn.rollback()
                return "error", None
            a, b = (utr_aliases(utr) + [utr, utr])[:2]
            if cur.execute("SELECT 1 FROM payment_utrs WHERE UPPER(utr) IN (?,?) LIMIT 1", (a.upper(), b.upper())).fetchone():
                conn.rollback()
                return "duplicate_utr", row
            try:
                cur.execute("INSERT INTO payment_utrs (utr, order_id, user_id, amount, received_amount, paid_at, credited_at) "
                            "VALUES (?,?,?,?,?,?,?)",
                            (utr, order_id, row["user_id"], int(row["amount"]), received_paise / 100.0, paid_at, epoch_now()))
            except sqlite3.IntegrityError:
                conn.rollback()
                return "duplicate_utr", row
            cur.execute("UPDATE pending_payments SET status='success', utr=?, received_amount=?, paid_at=?, reject_reason=NULL "
                        "WHERE id=? AND status IN ('pending','expired')", (utr, received_paise / 100.0, paid_at, row["id"]))
            if cur.rowcount != 1:
                conn.rollback()
                return "not_open", None
            conn.commit()
            return "credited", row
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            log.error("credit error: %s", e)
            return "error", None
        finally:
            cur.close()
            conn.close()


class App:
    def __init__(self, cfg, fs, db_path, grace=1200, notify=None):
        self.cfg, self.fs, self.db_path, self.grace = cfg, fs, db_path, grace
        self.notify = notify or (lambda text: None)
        self.sync_lock = threading.Lock()
        hooks = Hooks(get_db=self.get_db, notify_admin=self._admin_event,
                      on_credited=lambda uid, amt, utr, oid: threading.Thread(target=self.sync_paid, daemon=True).start(),
                      send_default_success=False)
        self.gw = SiteGateway(cfg, hooks)
        self.gw.init()
        c = self.get_db()
        c.execute("CREATE TABLE IF NOT EXISTS site_synced (order_id TEXT PRIMARY KEY, at INTEGER NOT NULL)")
        c.commit()
        c.close()

    def get_db(self):
        c = sqlite3.connect(self.db_path, timeout=30, check_same_thread=False)
        c.row_factory = sqlite3.Row
        return c

    def _admin_event(self, event, **kw):
        if event in ("UTR_VERIFICATION_FAILED", "SUSPICIOUS_PAYMENT", "PAYMENT_GATEWAY_ERROR", "PAYMENT_ERROR"):
            self.notify(f"[{event}] order {kw.get('ref', '')} | {kw.get('details', '')}")

    # ---- push verified payments into Firestore (also retried by the loop below)
    def sync_paid(self):
        if not self.sync_lock.acquire(blocking=False):
            return
        try:
            c = self.get_db()
            rows = c.execute("SELECT order_id, utr FROM pending_payments WHERE status='success' AND order_id NOT IN "
                             "(SELECT order_id FROM site_synced)").fetchall()
            c.close()
            for r in rows:
                oid = r["order_id"]
                try:
                    order, ut = self.fs.get(f"orders/{oid}")
                    if order is None:
                        continue
                    if order.get("paymentStatus") != "PAID":
                        self.fs.mark_paid(oid, order, ut, r["utr"])
                    c = self.get_db()
                    c.execute("INSERT OR IGNORE INTO site_synced VALUES (?,?)", (oid, epoch_now()))
                    c.commit()
                    c.close()
                    log.info("order %s marked PAID", oid)
                    self.notify(f"Order {oid} auto-verified and marked PAID (UTR {r['utr']})")
                except Exception as e:
                    log.error("sync %s failed: %s", oid, e)
        finally:
            self.sync_lock.release()

    def start(self):
        self.gw.start_worker()

        def loop():
            while True:
                try:
                    self.sync_paid()
                except Exception as e:
                    log.error("sync loop: %s", e)
                time.sleep(20)
        threading.Thread(target=loop, daemon=True, name="sync").start()

    # ---- API logic
    def status(self, order_id):
        row = self.gw.get_order(order_id)
        if not row:
            return {"state": "none"}
        st = row["status"]
        if st == "success":
            return {"state": "paid"}
        if st == "review":
            return {"state": "review", "message": REVIEW_MSG_EN.get(row["reject_reason"], "We could not verify this payment automatically.")}
        if st == "cancelled":
            return {"state": "none"}
        return {"state": "checking"}

    def verify(self, order_id):
        if not ORDER_RX.match(order_id or ""):
            return {"state": "error", "message": "Invalid order id."}, 400
        order, _ut = self.fs.get(f"orders/{order_id}")
        if order is None:
            return {"state": "error", "message": "Order not found."}, 404
        if order.get("paymentStatus") == "PAID":
            return {"state": "paid"}, 200
        if order.get("paymentMethod") != "UPI" or order.get("paymentStatus") != "PENDING":
            return {"state": "error", "message": "This order is not waiting for a UPI payment."}, 400
        existing = self.gw.get_order(order_id)
        if existing:
            return self.status(order_id), 200
        utr = normalize_utr(order.get("upiTransactionRef"))
        if not utr:
            return {"state": "review", "message": "The UTR on this order looks invalid. The store will check it manually."}, 200
        try:
            total = Decimal(str(order.get("total")))
        except InvalidOperation:
            total = Decimal(0)
        if total != total.to_integral_value() or not (self.cfg.min_amount <= total <= self.cfg.max_amount):
            return {"state": "review", "message": "This order amount needs a manual check."}, 200
        created = order.get("createdAt")
        created_ts = int(created.timestamp()) if isinstance(created, datetime) else epoch_now()
        phone = re.sub(r"\D", "", str(order.get("phone") or ""))[-10:]
        uid = int(phone) if phone else 0
        # The QR is shown (and the customer pays) BEFORE the order is saved, so allow a short grace period.
        try:
            c = self.get_db()
            c.execute("INSERT INTO pending_payments (user_id, order_id, amount, expected_amount, status, created_at, pay_method) "
                      "VALUES (?,?,?,?, 'pending', ?, 'upi_gmail')",
                      (uid, order_id, int(total), int(total), created_ts - self.grace))
            c.commit()
            c.close()
        except sqlite3.IntegrityError:
            return self.status(order_id), 200
        ok, code = self.gw.submit_utr(uid, order_id, utr, auto_verify=True)
        if not ok:
            msgs = {"duplicate_utr": "This UTR has already been used for another payment.",
                    "invalid_utr": "The UTR looks invalid."}
            self.gw._run("UPDATE pending_payments SET status='review', reject_reason=? WHERE order_id=?",
                         ("duplicate_utr" if code == "duplicate_utr" else "unverified", order_id))
            return {"state": "review", "message": msgs.get(code, "We could not verify this payment automatically.")}, 200
        return {"state": "checking"}, 200


REVIEW_MSG_EN = {
    "amount_mismatch": "The payment amount did not match the order total.",
    "amount_unreadable": "We could not read the amount from the payment e-mail.",
    "time_unreadable": "We could not verify the payment time.",
    "payment_before_order": "This payment was made too long before the order.",
    "payment_too_late": "This payment was made too long after the order.",
    "future_timestamp": "The payment e-mail time looked invalid.",
    "time_inconsistent": "The payment time did not match.",
    "payment_after_utr_submit": "The payment time looked invalid.",
    "duplicate_utr": "This UTR has already been used for another payment.",
    "email_not_found_timeout": "We did not receive the payment confirmation e-mail yet.",
}


# ----------------------------------------------------------------------------- web
def create_web(app: App, origins):
    from flask import Flask, jsonify, request
    web = Flask(__name__)
    hits = {}

    def limited(key, per_min=20):
        now = time.time()
        q = [t for t in hits.get(key, []) if now - t < 60]
        q.append(now)
        hits[key] = q
        if len(hits) > 5000:
            hits.clear()
        return len(q) > per_min

    @web.after_request
    def cors(resp):
        o = request.headers.get("Origin", "")
        if o and (o in origins or "*" in origins):
            resp.headers["Access-Control-Allow-Origin"] = o
            resp.headers["Vary"] = "Origin"
            resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
            resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        return resp

    @web.route("/api/fampay/verify", methods=["POST", "OPTIONS"])
    def verify():
        if request.method == "OPTIONS":
            return "", 204
        ip = request.headers.get("CF-Connecting-IP") or request.remote_addr or "?"
        if limited("v" + ip):
            return jsonify(state="error", message="Too many requests. Please wait a minute."), 429
        body = request.get_json(silent=True) or {}
        try:
            out, code = app.verify(str(body.get("orderId", "")).strip().upper())
        except Exception as e:
            log.exception("verify failed: %s", e)
            out, code = {"state": "error", "message": "Server error. The store will verify manually."}, 500
        return jsonify(out), code

    @web.route("/api/fampay/status/<order_id>")
    def status(order_id):
        ip = request.headers.get("CF-Connecting-IP") or request.remote_addr or "?"
        if limited("s" + ip, 90):
            return jsonify(state="error"), 429
        if not ORDER_RX.match(order_id.upper()):
            return jsonify(state="none")
        return jsonify(app.status(order_id.upper()))

    @web.route("/api/fampay/health")
    def health():
        return jsonify(ok=True, configured=app.cfg.configured, gmail_paused=app.gw.mail.paused)

    return web


def send_telegram(token, chat_id):
    if not (token and chat_id):
        return lambda text: log.info("notify: %s", text)
    import requests

    def send(text):
        try:
            requests.post(f"https://api.telegram.org/bot{token}/sendMessage",
                          json={"chat_id": chat_id, "text": text[:3500]}, timeout=15)
        except Exception as e:
            log.warning("telegram notify failed: %s", e)
    return send


def main():
    load_dotenv()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    cfg = Config.from_env(gmail_app_password=env("GMAIL_APP_PASSWORD").replace(" ", ""),
                          min_amount=1, max_amount=100000)
    if not cfg.configured:
        raise SystemExit("Set GMAIL_ADDRESS, GMAIL_APP_PASSWORD and FAMPAY_UPI_ID in .env")
    key = env("GOOGLE_APPLICATION_CREDENTIALS", "service-account.json")
    if not os.path.exists(key):
        raise SystemExit(f"Firebase service-account key not found: {key} (see README-TERMUX.md step 3)")
    fs = Firestore(env("FIREBASE_PROJECT_ID", "vexacollection-630ed"), env("FIREBASE_DATABASE_ID", "default"), key)
    app = App(cfg, fs, env("DB_PATH", "site-payments.db"), int(env("PAY_BEFORE_ORDER_GRACE", "1200")),
              notify=send_telegram(env("TELEGRAM_BOT_TOKEN"), env("TELEGRAM_ADMIN_ID")))
    app.start()
    ok, msg = app.gw.mail.selftest()
    log.info("Gmail check: %s %s", "OK" if ok else "FAILED", msg)
    origins = {o.strip() for o in env("ALLOWED_ORIGINS").split(",") if o.strip()}
    web = create_web(app, origins)
    port = int(env("PORT", "8080"))
    try:
        from waitress import serve
        serve(web, host="0.0.0.0", port=port, threads=8)
    except ImportError:
        web.run(host="0.0.0.0", port=port, threaded=True)


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        from selftest import run
        sys.exit(run())
    main()
