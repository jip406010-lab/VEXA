# FamPay auto-verify server (Termux) — setup

Customer FamPay UPI pe pay karta hai → checkout pe UTR dalta hai → ye server Gmail me FamPay ki
mail match karta hai → order Firestore me **PAID** ho jata hai. Amount aur UTR hamesha **order se**
padhe jaate hain (browser se nahi), isliye customer fake amount nahi bhej sakta.

## 1. Termux install (Play Store wala purana hai — F-Droid se lo)
```
pkg update && pkg install python cloudflared -y
termux-setup-storage
```
Fir ye `fampay-server` folder phone me copy karo (jaise ~/fampay-server) aur:
```
cd ~/fampay-server
pip install -r requirements.txt
cp .env.example .env && nano .env
```

## 2. Gmail
Google Account → Security → 2-Step ON → App passwords → naya password → `.env` me
GMAIL_APP_PASSWORD. Gmail Settings → Forwarding and POP/IMAP → **IMAP enabled**.
FAMPAY_UPI_ID wahi rakho jo website ke QR me hai (neeche step 5).

## 3. Firebase service account (server ko order PAID likhne ke liye)
Firebase Console → Project settings → Service accounts → **Generate new private key** →
file ko `service-account.json` naam se isi folder me rakho.
⚠️ Ye file kisi ko mat do, website folder me mat daalo.

## 4. Test aur run
```
python server.py --selftest      # sab PASS aana chahiye
termux-wake-lock                 # phone ko sone se roko
python server.py
```
Dusre Termux session me internet pe expose karo (website HTTPS se call karegi):
```
cloudflared tunnel --url http://localhost:8080
```
Ye `https://xxxx.trycloudflare.com` dega — **ye har restart pe badalta hai.** Permanent URL ke liye
Cloudflare account + apna domain ka *named tunnel* use karo (free), ya ngrok ka free static domain:
`ngrok http --domain=yourname.ngrok-free.app 8080`.

Check: browser me `https://<tunnel-url>/api/fampay/health` → `{"ok":true,...}`

## 5. Website me jodo
`vexacollection/js/config.js` me:
```
upiId: "yourname@fam",                 // FamPay UPI ID (auto-verify sirf FamPay payments ka hota hai)
fampayApi: "https://<tunnel-url>",     // bina last slash ke
```
Agar Admin Panel → Settings me UPI ID bhara hai to wahan bhi FamPay ID kar do (wo config.js ko override karta hai).
Fir website dobara upload karo. `ALLOWED_ORIGINS` me apni website ka exact https address hona chahiye.

## Phone-server ke saath dhyan rakho
- Battery optimisation Termux ke liye OFF karo, charger lagaya rakho, WiFi/data on.
- Phone band/server band = auto-verify band. Tab bhi order PENDING rehta hai aur aap Admin se
  manually PAID kar sakte ho (purana tareeka chalta rahega). Server wapas chalte hi pending UTR
  dobara check hote hain (6 ghante tak).
- Pakka kaam ke liye baad me ₹300–500/month wala VPS better hai; ye wahi code hai, bas wahan chalana hai.
